# -*- coding: utf-8 -*-
from sklearn.feature_extraction.text import TfidfVectorizer
import io,os
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.datasets import fetch_20newsgroups
import sklearn
if __name__=='__main__':
    # label_map={'体育':0,'女性':1,'文学':2,'校园':3}
    stop_words=[line.strip() for line in io.open('stop\stopword.txt',encoding='utf-8').readlines()]
    tf=TfidfVectorizer(stop_words,max_df=0.5)
    train_contents=sklearn.datasets.load_files('train', description=None, categories=None, load_content=True, shuffle=True,
                                encoding='UTF-8', decode_error='strict', random_state=0)
    # features=tf.fit_transform(train_contents.data,train_contents.target_names)
    # print(tf.get_feature_names())
    # test_features=os.listdir('test\体育')+os.listdir('test\女性')+os.listdir('test\文学')+os.listdir('test\校园')
    # clf=MultinomialNB(alpha=0.001).fit(train_contents,label_map)
    # predicted_labels=clf.predict(test_features)
    # print(predicted_labels)
    # print(features)
    print(train_contents.data)

